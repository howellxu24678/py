#这个是我用scrapy写的下载铃木爱理图片的网络爬虫

爬的网址是: [http://tieba.baidu.com/p/4023230951](http://tieba.baidu.com/p/4023230951)

这样就可以静静地跪舔爱理酱啦～


##使用：

>scrapy crawl airi_image_spider

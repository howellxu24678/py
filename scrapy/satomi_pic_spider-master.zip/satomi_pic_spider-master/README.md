###这个是用scrapy拿来多页面抓取图片的sample

###抓取页面为:

[石原里美的豆瓣影人图集](http://movie.douban.com/celebrity/1016930/)
